package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.devtools.idealized.Javascript;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import base.basetest;

public class invalidloginpage extends basetest {
	
	WebElement btn_product;
	WebElement btn_solution;
	WebElement btn_resources;
	WebElement btn_login;
	WebElement btn_login2;
	WebElement txt_email;
	WebElement txt_password;
	WebElement btn_login3;
	
	public invalidloginpage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}
	
	public void clickonproductbtn() {
		WebElement product = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(loc.getProperty("btn_product"))));
		Actions action = new Actions(driver);
		action.moveToElement(product).perform();
	}
		
	public void clickonsolutionbtn() {
		WebElement solution = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(loc.getProperty("btn_solution"))));
		Actions action = new Actions(driver);
		action.moveToElement(solution).perform();
	}
	
	public void clickonresourcesbtn() {
		WebElement resources = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(loc.getProperty("btn_resources"))));
		Actions action = new Actions(driver);
		action.moveToElement(resources).perform();	
	}
	
	public void clickonbtn_login() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("btn_login")))).click();
	}
	
	public void clickonbtn_login2() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("btn_login2")))).click();
	}
	

	public void enteremail(String email) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("txt_email"))))
				.sendKeys(email);
	}
	
	public void enterPassword(String password) {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("txt_password"))))
				.sendKeys(password);
	}
	
	public void clickonbtn_login3() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("btn_login3")))).click();
	}
}