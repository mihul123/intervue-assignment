package testcases;
 
import java.io.IOException;
 
import org.testng.annotations.Test;
 
import base.basetest;
import pages.loginpage;
import utilities.readXLData;
 
public class login extends basetest {
	loginpage login;
	@Test(dataProviderClass = readXLData.class, dataProvider = "testData")
	public void login(String email, String password) throws InterruptedException, IOException {
		login = new loginpage(driver);
		login.clickonproductbtn();
		login.clickonsolutionbtn();
		login.clickonresourcesbtn();
		login.clickonbtn_login();
		switchToNewTab();
		login.clickonbtn_login2();
		login.enteremail(email);
		login.enterPassword(password);
		login.clickonbtn_login3();
		login.clickonbtn_profile();
		login.clickonbtn_logout();	
	}
}