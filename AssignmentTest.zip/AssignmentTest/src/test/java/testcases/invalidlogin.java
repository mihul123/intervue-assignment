package testcases;
 
import java.io.IOException;
 
import org.testng.annotations.Test;
 
import base.basetest;
import pages.invalidloginpage;
import utilities.readXLData;
 
public class invalidlogin extends basetest {
	invalidloginpage invalidlogin;
	@Test(dataProviderClass = readXLData.class, dataProvider = "testData")
	public void invalidlogin(String email, String password) throws InterruptedException, IOException {
		invalidlogin = new invalidloginpage(driver);
		invalidlogin.clickonproductbtn();
		invalidlogin.clickonsolutionbtn();
		invalidlogin.clickonresourcesbtn();
		invalidlogin.clickonbtn_login();
		switchToNewTab();
		invalidlogin.clickonbtn_login2();
		invalidlogin.enteremail(email);
		invalidlogin.enterPassword(password);
		invalidlogin.clickonbtn_login3();
	}
}